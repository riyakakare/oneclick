# ChatGPT Reverse Proxy Setup Guide

## ChatGPT Cookies Kaise Nikale?

### Step-by-Step Instructions:

1. **ChatGPT par login karo:**
   - Browser mein https://chatgpt.com/ kholo
   - Apne account se login karo

2. **Developer Tools kholo:**
   - Press `F12` ya `Ctrl+Shift+I`
   - Ya right-click karke "Inspect" select karo

3. **Application/Storage tab mein jao:**
   - Top menu mein "Application" tab click karo
   - Left sidebar mein "Cookies" expand karo
   - "https://chatgpt.com" select karo

4. **Important Cookies Copy Karo:**

   Ye cookies zaruri hain:
   
   - `__Secure-next-auth.session-token` - Ye sabse important hai (login session)
   - `__Host-next-auth.csrf-token` - Security token
   - `_cfuvid` - Cloudflare verification
   - `cf_clearance` - Cloudflare clearance (agar dikhe)

5. **Config.json mein paste karo:**
   - Har cookie ki "Value" column se value copy karo
   - `config.json` file mein corresponding jagah paste karo

## Example:

Agar aapka session token ye hai:
```
eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2R0NNIn0..abcd1234...
```

To config.json mein aise paste karo:
```json
{
  "name": "__Secure-next-auth.session-token",
  "value": "eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2R0NNIn0..abcd1234...",
  "domain": ".chatgpt.com",
  "path": "/",
  "httpOnly": true,
  "secure": true
}
```

## Server Start Karo:

```bash
npm install
npm start
```

Server `http://localhost:3000` par run hoga.

## Important Notes:

⚠️ **Session Expiry**: ChatGPT ke session tokens expire ho jate hain (usually 30 days). Agar kaam na kare to naye cookies nikalo.

⚠️ **Cloudflare Protection**: ChatGPT Cloudflare use karta hai. Agar issues aaye to:
- `cf_clearance` cookie bhi add karo
- User-Agent exactly same rakho
- IP address same rakho (VPN use mat karo)

⚠️ **Rate Limiting**: Bahut zyada requests mat bhejo, account ban ho sakta hai.

⚠️ **Legal**: Ye sirf personal testing ke liye hai. OpenAI ke Terms of Service follow karo.

## Troubleshooting:

**"Unauthorized" error:**
- Cookies expire ho gaye honge, naye nikalo
- Session token sahi se copy nahi hua

**Cloudflare challenge:**
- `cf_clearance` cookie add karo
- Browser ka exact User-Agent use karo

**Blank page:**
- Console mein errors check karo
- Network tab mein dekho kaunsi requests fail ho rahi hain
