# 🛡️ Cloudflare Verification Issue - Solution

## Problem
Kuch websites Cloudflare protection use karti hain jo proxy requests ko block kar deti hai.

## Solution

### Step 1: Cloudflare Cookies Import Karo

Ye cookies **zaruri** hain Cloudflare bypass karne ke liye:

1. **cf_clearance** - Sabse important cookie
2. **__cf_bm** - Bot management cookie
3. **__cfuvid** - User verification cookie

### Step 2: Cookies Kaise Nikale?

1. Target website par **normal browser** mein jao
2. Agar Cloudflare challenge aaye to complete karo (checkbox click karo)
3. Website load hone ke baad **F12** press karo
4. **Application** → **Cookies** → Website select karo
5. Ye 3 cookies dhundo aur copy karo:
   - `cf_clearance`
   - `__cf_bm`
   - `__cfuvid`

### Step 3: Browser Extension Use Karo (Recommended)

**Chrome/Edge:**
1. "EditThisCookie" extension install karo
2. Website par jao aur Cloudflare challenge complete karo
3. Extension icon click karo
4. "Export" button click karo (JSON format)
5. Sari cookies copy ho jayengi

**Firefox:**
1. "Cookie Quick Manager" extension install karo
2. Same process follow karo

### Step 4: Admin Panel Mein Import Karo

1. `http://localhost:3000/admin` kholo
2. **Bulk Import Cookies** section mein paste karo
3. "Import All Cookies" click karo
4. Server restart karo

## Important Notes

### Cookie Expiry
- Cloudflare cookies **expire** ho jati hain (usually 30 minutes to 24 hours)
- Agar site nahi khul rahi to **naye cookies** import karo
- Regular basis par cookies update karte raho

### User-Agent Matching
- Browser ka **exact same User-Agent** use karo
- Admin panel mein already set hai, but agar issue ho to:
  1. Browser mein console kholo
  2. Type karo: `navigator.userAgent`
  3. Copy karke config mein paste karo

### IP Address
- Cookies jis IP se generate hui thi, **same IP** se use karo
- VPN change mat karo cookies generate karne ke baad
- Mobile aur desktop ke cookies alag hote hain

## Advanced: Manual Headers

Agar phir bhi issue ho to ye headers add karo (already server mein set hain):

```javascript
"Sec-Ch-Ua": '"Not_A Brand";v="8", "Chromium";v="120"'
"Sec-Ch-Ua-Mobile": "?0"
"Sec-Ch-Ua-Platform": '"Windows"'
"Sec-Fetch-Dest": "document"
"Sec-Fetch-Mode": "navigate"
"Sec-Fetch-Site": "none"
"Sec-Fetch-User": "?1"
```

## Testing

1. Browser mein website kholo aur Cloudflare pass karo
2. Cookies export karo
3. Admin panel mein import karo
4. Server restart karo
5. `http://localhost:3000` test karo

## Common Errors

### "Checking your browser"
- `cf_clearance` cookie missing hai ya expire ho gayi
- Naye cookies import karo

### "Access Denied"
- IP address change ho gaya
- User-Agent match nahi ho raha
- Cookies expire ho gayi

### "Too Many Requests"
- Rate limiting lag gayi
- Thoda wait karo (5-10 minutes)
- Naye cookies generate karo

## Pro Tips

✅ Cookies ko **immediately** use karo generate karne ke baad
✅ Same browser ka User-Agent use karo
✅ IP address constant rakho
✅ Cookies ko **regularly update** karo (daily recommended)
✅ Incognito mode se cookies generate mat karo

## Example: ChatGPT Cloudflare Cookies

```json
[
  {
    "name": "cf_clearance",
    "value": "your_clearance_token_here",
    "domain": ".chatgpt.com",
    "path": "/",
    "httpOnly": true,
    "secure": true
  },
  {
    "name": "__cf_bm",
    "value": "your_bm_token_here",
    "domain": ".chatgpt.com",
    "path": "/",
    "httpOnly": true,
    "secure": true
  },
  {
    "name": "__cfuvid",
    "value": "your_uvid_token_here",
    "domain": ".chatgpt.com",
    "path": "/",
    "httpOnly": true,
    "secure": true
  }
]
```

## Still Not Working?

1. Browser DevTools mein Network tab check karo
2. Console mein errors dekho
3. Server logs check karo
4. Cookies fresh hain confirm karo (5 minutes se purani nahi)
5. Browser aur proxy ka User-Agent exactly same hai confirm karo

---

**Note:** Cloudflare bypass karna legal grey area mein hai. Sirf apni personal websites ya testing ke liye use karo.
