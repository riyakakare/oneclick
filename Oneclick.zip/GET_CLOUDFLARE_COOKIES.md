# 🔥 Cloudflare Cookies Kaise Nikale - Step by Step

## Problem
Aapke config mein **cf_clearance** cookie missing hai jo Cloudflare bypass ke liye zaruri hai.

## Solution - 2 Easy Methods

---

## Method 1: Browser Extension (RECOMMENDED - Sabse Easy)

### Step 1: Extension Install Karo

**Chrome/Edge:**
1. Chrome Web Store kholo
2. Search karo: "EditThisCookie"
3. Install karo

**Firefox:**
1. Firefox Add-ons kholo
2. Search karo: "Cookie Quick Manager"
3. Install karo

### Step 2: Cookies Export Karo

1. **Browser mein target website kholo** (example: https://claude.ai)
2. **Login karo** apne account se
3. **Agar Cloudflare challenge aaye** to complete karo (checkbox click karo)
4. Website **fully load** hone do
5. **Extension icon** click karo (top-right corner mein)
6. **"Export"** button click karo
7. **JSON format** select karo
8. **Copy** karo sari cookies

### Step 3: Admin Panel Mein Import Karo

1. `http://localhost:3000/admin` kholo
2. **"Bulk Import Cookies"** section mein jao
3. Copied JSON **paste** karo
4. **"Import All Cookies"** button click karo
5. **"Restart Server"** button click karo
6. Done! ✅

---

## Method 2: Manual (Browser DevTools)

### Step 1: Website Par Jao

1. Browser mein target website kholo
2. Login karo
3. Cloudflare challenge complete karo
4. Website fully load hone do

### Step 2: DevTools Kholo

1. Press **F12** (ya Right-click → Inspect)
2. **Application** tab click karo (ya Storage tab Firefox mein)
3. Left sidebar mein **Cookies** expand karo
4. Website URL select karo

### Step 3: Important Cookies Copy Karo

**Cloudflare Cookies (MUST HAVE):**
- `cf_clearance` ⭐ **MOST IMPORTANT**
- `__cf_bm`
- `_cfuvid`

**Session Cookies (for logged-in state):**
- Session tokens (har website ke alag naam hote hain)
- Auth tokens
- User ID cookies

### Step 4: Console Mein Export Karo

DevTools mein **Console** tab kholo aur ye code paste karo:

```javascript
// Sari cookies export karo JSON format mein
copy(JSON.stringify(
  document.cookie.split('; ').map(c => {
    const [name, value] = c.split('=');
    return {
      name,
      value,
      domain: window.location.hostname,
      path: '/',
      httpOnly: false,
      secure: true
    };
  }),
  null,
  2
));
```

Press **Enter** - cookies clipboard mein copy ho jayengi!

### Step 5: Admin Panel Mein Import Karo

1. `http://localhost:3000/admin` kholo
2. Bulk Import section mein paste karo
3. Import button click karo
4. Server restart karo

---

## Method 3: Network Tab Se (Advanced)

1. **F12** → **Network** tab
2. Website reload karo
3. Koi bhi request select karo
4. **Headers** section mein dekho
5. **Request Headers** → **Cookie** dekho
6. Sari cookies copy karo

---

## ⚠️ Important Notes

### Cookie Expiry
- `cf_clearance` cookie **30 minutes to 24 hours** mein expire ho jati hai
- Agar site nahi khul rahi = cookies expire ho gayi
- **Fresh cookies** generate karo aur import karo

### Same Browser
- Jis browser se cookies nikali, **same browser ka User-Agent** use karo
- Admin panel mein User-Agent check karo

### Same IP
- Cookies jis IP se generate hui, **same IP** se use karo
- VPN change mat karo

### Timing
- Cookies generate karne ke **turant baad** import karo
- 5 minutes se zyada purani cookies kaam nahi karengi

---

## 🎯 Quick Test

### Check Karo Cookies Sahi Hain Ya Nahi:

1. Browser mein website kholo
2. F12 → Application → Cookies
3. Ye cookies honi chahiye:
   - ✅ `cf_clearance` (Cloudflare)
   - ✅ `__cf_bm` (Cloudflare)
   - ✅ Session/Auth cookies

4. Agar `cf_clearance` missing hai = Cloudflare challenge complete nahi hua

---

## 🔧 Troubleshooting

### "Checking your browser" message
❌ **Problem:** `cf_clearance` cookie missing
✅ **Solution:** Naye cookies import karo

### "Access Denied"
❌ **Problem:** Cookies expire ho gayi ya IP change ho gaya
✅ **Solution:** Fresh cookies generate karo same IP se

### "Too Many Requests"
❌ **Problem:** Rate limiting
✅ **Solution:** 10 minutes wait karo, phir naye cookies generate karo

### Site load nahi ho rahi
❌ **Problem:** Cookies properly forward nahi ho rahi
✅ **Solution:** 
1. Server logs check karo
2. Browser console mein errors dekho
3. Cookies fresh hain confirm karo

---

## 📋 Example: Complete Cookie Set

```json
[
  {
    "name": "cf_clearance",
    "value": "abc123xyz...",
    "domain": ".example.com",
    "httpOnly": true,
    "secure": true
  },
  {
    "name": "__cf_bm",
    "value": "def456...",
    "domain": ".example.com",
    "httpOnly": true,
    "secure": true
  },
  {
    "name": "session_token",
    "value": "ghi789...",
    "domain": ".example.com",
    "httpOnly": true,
    "secure": true
  }
]
```

---

## 🚀 Final Steps

1. ✅ Browser extension install karo (EditThisCookie)
2. ✅ Target website par jao aur login karo
3. ✅ Cloudflare challenge complete karo
4. ✅ Extension se cookies export karo
5. ✅ Admin panel mein import karo
6. ✅ Server restart karo
7. ✅ Test karo: `http://localhost:3000`

**Agar phir bhi issue ho to:**
- Cookies 5 minutes se purani nahi honi chahiye
- Browser ka exact User-Agent use karo
- Same IP address se access karo
- Incognito mode se cookies generate mat karo

---

**Pro Tip:** Cookies ko daily update karo for best results! 🎯
