# Reverse Proxy Server with Cookie Injection

Kisi bhi website ko apne server par run karo with automatic cookie injection.

## Setup

1. **Dependencies install karo:**
```bash
npm install
```

2. **Configuration setup karo:**
`config.json` file mein apni settings add karo:

- `port`: Apne server ka port (default: 3000)
- `targetUrl`: Jis website ko proxy karna hai uska URL
- `cookies`: Jo cookies inject karni hain (logged-in state ke liye)
- `customHeaders`: Extra headers agar chahiye

## Cookie Kaise Nikale?

1. Target website par browser mein login karo
2. Developer Tools kholo (F12)
3. Application/Storage tab mein jao
4. Cookies section mein dekho
5. Important cookies (session_id, auth_token, etc.) copy karo
6. `config.json` mein paste karo

## Usage

```bash
npm start
```

Server `http://localhost:3000` par run hoga aur target website ko serve karega with injected cookies.

## Example Configuration

```json
{
  "port": 3000,
  "targetUrl": "https://facebook.com",
  "cookies": [
    {
      "name": "c_user",
      "value": "100012345678",
      "domain": ".facebook.com",
      "path": "/",
      "httpOnly": false,
      "secure": true
    },
    {
      "name": "xs",
      "value": "your_xs_cookie_value",
      "domain": ".facebook.com",
      "path": "/",
      "httpOnly": true,
      "secure": true
    }
  ]
}
```

## Important Notes

⚠️ **Legal Warning**: Ye tool sirf educational purposes ke liye hai. Kisi bhi website ko unauthorized access karna illegal hai.

- Sirf apni khud ki websites ya testing ke liye use karo
- Dusre logo ke accounts access karna crime hai
- Terms of Service follow karo

## Features

✅ Kisi bhi website ko proxy karo
✅ Automatic cookie injection
✅ Custom headers support
✅ HTTPS support
✅ Easy configuration
✅ Request/Response logging

## Troubleshooting

**CORS errors**: Kuch websites CORS restrictions use karti hain. Aise mein additional headers add karo.

**Cookie not working**: Domain aur path correctly set karo. Browser DevTools mein check karo ki cookies set ho rahi hain ya nahi.

**SSL errors**: Agar target site HTTPS hai to `secure: true` use karo cookies mein.
