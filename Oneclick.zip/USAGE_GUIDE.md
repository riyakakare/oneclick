# 🚀 Universal Reverse Proxy - Usage Guide

## Kaise Use Kare?

### Step 1: Server Start Karo
```bash
npm install
npm start
```
Ya double-click: `start.bat`

### Step 2: Admin Panel Kholo
```
http://localhost:3000/admin
```

### Step 3: Target Website Set Karo

**Basic Settings** section mein:
- **Target URL** mein koi bhi website ka URL dalo
  - Example: `https://chatgpt.com`
  - Example: `https://facebook.com`
  - Example: `https://twitter.com`
  - Example: `https://instagram.com`

### Step 4: Cookies Import Karo

1. Target website par browser mein login karo
2. Browser extension use karke cookies export karo (JSON format)
   - Chrome: "EditThisCookie" extension
   - Firefox: "Cookie Quick Manager"
3. Admin panel mein **Bulk Import Cookies** section mein paste karo
4. "Import All Cookies" click karo

### Step 5: Server Restart Karo

Admin panel mein "Restart Server" button click karo

### Step 6: Access Karo

```
http://localhost:3000
```

Ab target website aapke server par chalegi with injected cookies!

## ✨ Features

✅ **Koi bhi website** - Sirf URL change karo
✅ **Sare pages** - Website ke har page aapke domain par chalega
✅ **Logged-in state** - Cookies inject hoti hain automatically
✅ **Easy management** - Admin panel se sab control karo
✅ **Bulk import** - Ek saath sari cookies import karo

## 🎯 Examples

### ChatGPT
```
Target URL: https://chatgpt.com
Access: http://localhost:3000
```

### Facebook
```
Target URL: https://facebook.com
Access: http://localhost:3000
```

### Instagram
```
Target URL: https://instagram.com
Access: http://localhost:3000
```

### Twitter/X
```
Target URL: https://twitter.com
Access: http://localhost:3000
```

## 🔄 Website Change Karna

1. Admin panel kholo
2. Target URL change karo
3. Naye website ke cookies import karo
4. Server restart karo
5. Done! ✅

## 📝 Important Notes

- Har website ke liye alag cookies chahiye
- Cookies expire ho jate hain (naye import karo agar kaam na kare)
- Kuch websites extra security use karti hain (Cloudflare, etc.)
- Sirf personal/testing use ke liye

## 🛠️ Troubleshooting

**Website load nahi ho rahi:**
- Target URL sahi hai check karo
- Internet connection check karo
- Console mein errors dekho

**Logged-in nahi dikh raha:**
- Cookies expire ho gaye honge
- Naye cookies import karo
- Browser DevTools mein check karo cookies set ho rahi hain ya nahi

**Cloudflare error:**
- `cf_clearance` cookie import karo
- User-Agent exactly same rakho
- IP address same rakho

## 🎨 Customization

Admin panel se customize kar sakte ho:
- Port number
- Target URL
- Cookies
- Custom headers (advanced)

## ⚠️ Legal Warning

Ye tool sirf educational aur personal testing ke liye hai. Kisi bhi website ko unauthorized access karna illegal hai. Apni responsibility par use karo.
