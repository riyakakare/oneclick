const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');

puppeteer.use(StealthPlugin());

class CloudflareBypass {
  constructor() {
    this.browser = null;
    this.page = null;
    this.cookies = [];
    this.userAgent = '';
  }

  async initialize(targetUrl) {
    console.log('🔧 Initializing Cloudflare Bypass...');
    
    this.browser = await puppeteer.launch({
      headless: 'new',
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--disable-gpu',
        '--window-size=1920x1080',
        '--disable-blink-features=AutomationControlled'
      ]
    });

    this.page = await this.browser.newPage();
    
    // Set realistic viewport
    await this.page.setViewport({ width: 1920, height: 1080 });
    
    // Get user agent
    this.userAgent = await this.page.evaluate(() => navigator.userAgent);
    
    console.log('🌐 Loading target URL:', targetUrl);
    
    try {
      // Navigate with timeout
      await this.page.goto(targetUrl, {
        waitUntil: 'networkidle2',
        timeout: 30000
      });
      
      // Wait for Cloudflare challenge to complete
      console.log('⏳ Waiting for Cloudflare challenge...');
      await this.page.waitForTimeout(5000);
      
      // Check if we're past Cloudflare
      const title = await this.page.title();
      console.log('📄 Page title:', title);
      
      // Get cookies
      this.cookies = await this.page.cookies();
      console.log('🍪 Cookies obtained:', this.cookies.length);
      
      return {
        success: true,
        cookies: this.cookies,
        userAgent: this.userAgent
      };
      
    } catch (error) {
      console.error('❌ Error during bypass:', error.message);
      return {
        success: false,
        error: error.message
      };
    }
  }

  async close() {
    if (this.browser) {
      await this.browser.close();
      console.log('🔒 Browser closed');
    }
  }

  getCookies() {
    return this.cookies;
  }

  getUserAgent() {
    return this.userAgent;
  }
}

module.exports = CloudflareBypass;
