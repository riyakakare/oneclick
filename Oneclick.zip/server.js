const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const cookieParser = require('cookie-parser');
const fs = require('fs');
const path = require('path');
const CloudflareBypass = require('./cloudflare-bypass');

const app = express();

// Middleware for JSON parsing
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Config load karo
let config = JSON.parse(fs.readFileSync('config.json', 'utf8'));

app.use(cookieParser());

// Admin Panel Route
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'admin.html'));
});

// API Routes for Admin Panel
app.get('/api/config', (req, res) => {
  res.json(config);
});

app.post('/api/config', (req, res) => {
  try {
    config = req.body;
    fs.writeFileSync('config.json', JSON.stringify(config, null, 2));
    res.json({ success: true, message: 'Configuration updated successfully' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.post('/api/restart', (req, res) => {
  res.json({ success: true, message: 'Server restarting...' });
  setTimeout(() => {
    process.exit(0);
  }, 1000);
});

// Cloudflare Bypass API
app.post('/api/bypass-cloudflare', async (req, res) => {
  try {
    console.log('🚀 Starting Cloudflare bypass...');
    const bypass = new CloudflareBypass();
    const result = await bypass.initialize(config.targetUrl);
    
    if (result.success) {
      // Update config with new cookies
      config.cookies = result.cookies.map(cookie => ({
        name: cookie.name,
        value: cookie.value,
        domain: cookie.domain,
        path: cookie.path,
        httpOnly: cookie.httpOnly,
        secure: cookie.secure
      }));
      
      // Update User-Agent
      if (!config.customHeaders) {
        config.customHeaders = {};
      }
      config.customHeaders['User-Agent'] = result.userAgent;
      
      // Save config
      fs.writeFileSync('config.json', JSON.stringify(config, null, 2));
      
      await bypass.close();
      
      res.json({
        success: true,
        message: 'Cloudflare bypassed successfully!',
        cookiesCount: config.cookies.length
      });
    } else {
      await bypass.close();
      res.status(500).json({
        success: false,
        message: 'Failed to bypass Cloudflare: ' + result.error
      });
    }
  } catch (error) {
    console.error('❌ Bypass error:', error);
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
});

// Cookie injection middleware
app.use((req, res, next) => {
  // Inject cookies from config
  if (config.cookies && config.cookies.length > 0) {
    const cookieStrings = config.cookies.map(cookie => {
      let cookieStr = `${cookie.name}=${cookie.value}`;
      if (cookie.domain) cookieStr += `; Domain=${cookie.domain}`;
      if (cookie.path) cookieStr += `; Path=${cookie.path}`;
      if (cookie.httpOnly) cookieStr += `; HttpOnly`;
      if (cookie.secure) cookieStr += `; Secure`;
      if (cookie.maxAge) cookieStr += `; Max-Age=${cookie.maxAge}`;
      return cookieStr;
    });
    
    // Set cookies in response
    cookieStrings.forEach(cookieStr => {
      res.setHeader('Set-Cookie', cookieStr);
    });
  }
  next();
});

// Proxy configuration
const proxyOptions = {
  target: config.targetUrl,
  changeOrigin: true,
  selfHandleResponse: false,
  followRedirects: true,
  
  onProxyReq: (proxyReq, req, res) => {
    // Safe header removal - check if headers exist before removing
    try {
      if (proxyReq.getHeader('x-forwarded-for')) {
        proxyReq.removeHeader('x-forwarded-for');
      }
      if (proxyReq.getHeader('x-forwarded-host')) {
        proxyReq.removeHeader('x-forwarded-host');
      }
      if (proxyReq.getHeader('x-forwarded-proto')) {
        proxyReq.removeHeader('x-forwarded-proto');
      }
    } catch (e) {
      // Ignore header removal errors
    }
    
    // Custom headers add karo
    if (config.customHeaders) {
      Object.keys(config.customHeaders).forEach(key => {
        try {
          proxyReq.setHeader(key, config.customHeaders[key]);
        } catch (e) {
          // Ignore header setting errors
        }
      });
    }
    
    // Cloudflare bypass headers
    try {
      proxyReq.setHeader('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8');
      proxyReq.setHeader('Accept-Encoding', 'gzip, deflate, br');
      proxyReq.setHeader('Accept-Language', 'en-US,en;q=0.9');
      proxyReq.setHeader('Cache-Control', 'max-age=0');
      proxyReq.setHeader('Sec-Ch-Ua', '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"');
      proxyReq.setHeader('Sec-Ch-Ua-Mobile', '?0');
      proxyReq.setHeader('Sec-Ch-Ua-Platform', '"Windows"');
      proxyReq.setHeader('Sec-Fetch-Dest', 'document');
      proxyReq.setHeader('Sec-Fetch-Mode', 'navigate');
      proxyReq.setHeader('Sec-Fetch-Site', 'none');
      proxyReq.setHeader('Sec-Fetch-User', '?1');
      proxyReq.setHeader('Upgrade-Insecure-Requests', '1');
    } catch (e) {
      // Ignore header setting errors
    }
    
    // Cookies ko forward karo
    if (config.cookies && config.cookies.length > 0) {
      try {
        const cookieHeader = config.cookies
          .map(c => `${c.name}=${c.value}`)
          .join('; ');
        proxyReq.setHeader('Cookie', cookieHeader);
      } catch (e) {
        // Ignore cookie header errors
      }
    }
    
    console.log(`[PROXY] ${req.method} ${req.url} -> ${config.targetUrl}${req.url}`);
  },
  
  onProxyRes: (proxyRes, req, res) => {
    // Response headers modify karo agar zarurat ho
    const setCookieHeaders = proxyRes.headers['set-cookie'];
    if (setCookieHeaders) {
      // Original cookies ko bhi forward karo
      proxyRes.headers['set-cookie'] = setCookieHeaders.map(cookie => {
        // Domain ko replace karo agar zarurat ho
        return cookie.replace(/Domain=[^;]+/gi, '');
      });
    }
  },
  
  onError: (err, req, res) => {
    console.error('[PROXY ERROR]', err.message);
    res.status(500).send('Proxy Error: ' + err.message);
  }
};

// Proxy middleware use karo
app.use('/', createProxyMiddleware(proxyOptions));

// Server start karo
app.listen(config.port, () => {
  console.log(`\n🚀 Reverse Proxy Server Running!`);
  console.log(`📍 Local: http://localhost:${config.port}`);
  console.log(`🎯 Target: ${config.targetUrl}`);
  console.log(`🍪 Cookies: ${config.cookies.length} configured`);
  console.log(`⚙️  Admin Panel: http://localhost:${config.port}/admin\n`);
});
